# Global Connect · Connected Journeys

A nine-second motion identity built around your existing globe and flight-path swooshes. The supplied company artwork provides every letter, the globe, the swooshes, the company descriptor and the trademark. The final hold uses the complete original artwork at the new composition size.

## Watch and use

Open **Watch-Animation.html** for the replayable preview. The preview starts muted; choose **Enable sound** for the original sonic signature. Keep the HTML in this folder so its video links work. The MP4 files also play independently.

| File | Purpose |
| --- | --- |
| `Global-Connect-Logo-Reveal-4K.mp4` | Main master: 3840 × 2160, 60 fps, stereo audio |
| `Global-Connect-Logo-Reveal-1080p.mp4` | Sharing copy: 1920 × 1080, 60 fps, stereo audio |
| `Global-Connect-Logo-Reveal-1080p-Silent.mp4` | For websites, presentations and edits with their own audio |
| `preview/animation-preview.gif` | Smaller looping preview, without sound |
| `preview/poster.png` | Full HD still of the final composition |
| `source/` | Original supplied logo, editable JavaScript choreography, renderer, original WAV and 4K silent intermediate |

All videos are nine seconds long, H.264 in MP4, with a white background. Audio versions use AAC stereo. The 4K file is rendered directly at 3840 × 2160; the supplied logo is raster artwork, not a vector file. The files do not contain transparency.

## Motion direction

| Time | Choreography |
| --- | --- |
| 0.00–1.55 s | Fine blue and lime travel arcs describe a sphere. The original globe resolves in a clockwise sweep. |
| 1.57–3.23 s | The globe travels into the O position. The other GLOBAL letters arrive from both sides with a gentle deceleration. |
| 2.16–4.44 s | Both existing blue swooshes draw on. CONNECT rises letter by letter, with a small stagger. |
| 4.11–4.95 s | TRAVELS PRIVATE LIMITED reveals; the trademark resolves into place. |
| 5.04–5.76 s | A restrained finishing highlight crosses the lockup. |
| 5.82–9.00 s | The complete supplied logo holds cleanly on white. |

The original sound design combines soft travel sweeps, a quiet tonal foundation and a short resolving bell signature. It was synthesized for this animation; no stock audio or external recording is included.

## Editable source

The source is a deterministic Canvas motion composition, not an After Effects or Lottie project. It needs Node.js, FFmpeg with libx264 and the dependency pinned in `source/package.json`.

From the `source` directory:

```text
npm install
node audio.cjs
node render.cjs --stills
node render.cjs
node render.cjs --width 3840 --height 2160 --output master-4k-silent.mp4
```

`FFMPEG_PATH` can point to an FFmpeg executable when it is not on PATH. Adjust the per-element start times, durations and motion in `scene.cjs`. The original logo is loaded locally; there are no network dependencies during rendering or playback.

To add the sound design to a silent render:

```text
ffmpeg -i input-silent.mp4 -i sonic-logo.wav -c:v copy -af loudnorm=I=-19:TP=-1.5:LRA=7 -c:a aac -b:a 192k -ar 48000 -t 9 -movflags +faststart output-with-sound.mp4
```

Preserve the original logo aspect ratio when resizing. The composition intentionally leaves space around the identity for use in presentation intros, video openings and closing cards.
