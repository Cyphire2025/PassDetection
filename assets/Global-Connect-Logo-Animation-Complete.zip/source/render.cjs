'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {once}=require('node:events');
const {createCanvas}=require('@napi-rs/canvas');
const {createScene,DURATION}=require('./scene.cjs');
const root=path.resolve(__dirname,'..');
const args=process.argv.slice(2);
const arg=(name,fallback)=>{const i=args.indexOf(name);return i>=0?args[i+1]:fallback;};

async function main(){
  const scene=await createScene();
  if(args.includes('--stills')){
    const times=[0.35,0.85,1.35,1.95,2.40,2.90,3.35,3.85,4.40,4.95,5.45,7.2];
    const sheet=createCanvas(1600,1044),ctx=sheet.getContext('2d');ctx.fillStyle='#e9edf1';ctx.fillRect(0,0,1600,1044);
    for(let i=0;i<times.length;i++){
      const frame=scene.render(times[i],960,540),x=16+(i%4)*396,y=16+Math.floor(i/4)*342;
      ctx.drawImage(frame,x,y,380,214);ctx.fillStyle='#243b53';ctx.font='20px Arial';ctx.fillText(`${times[i].toFixed(2)} s`,x,y+247);
      fs.writeFileSync(path.join(root,'qa',`frame-${String(i).padStart(2,'0')}.png`),frame.toBuffer('image/png'));
    }
    fs.writeFileSync(path.join(root,'qa','storyboard.jpg'),sheet.toBuffer('image/jpeg',92));
    fs.writeFileSync(path.join(root,'preview','poster.png'),scene.render(7.2).toBuffer('image/png'));
    console.log('Storyboard and native final frame ready.');return;
  }
  const width=Number(arg('--width','1920')),height=Number(arg('--height','1080')),fps=Number(arg('--fps','60'));
  const output=arg('--output',path.join(root,'Global-Connect-Logo-Reveal-1080p-Silent.mp4'));
  const ffmpeg=process.env.FFMPEG_PATH||'ffmpeg';
  const ff=spawn(ffmpeg,['-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pixel_format','rgba',
    '-video_size',`${width}x${height}`,'-framerate',String(fps),'-i','pipe:0','-an','-c:v','libx264',
    '-preset','medium','-crf','16','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709',
    '-colorspace','bt709','-movflags','+faststart','-metadata','title=Global Connect — Connected Journeys',output],{stdio:['pipe','ignore','pipe'],windowsHide:true});
  let err='';ff.stderr.on('data',d=>err+=d.toString());
  const done=new Promise((resolve,reject)=>{ff.once('error',reject);ff.once('close',code=>code===0?resolve():reject(new Error(`FFmpeg ${code}: ${err}`)));});
  ff.stdin.on('error',()=>{});
  const frames=Math.round(DURATION*fps),started=Date.now();
  for(let i=0;i<frames;i++){
    const frame=scene.render(i/fps,width,height);
    if(!ff.stdin.write(frame.data()))await once(ff.stdin,'drain');
    if(i%fps===0)console.log(`Rendered ${(i/fps).toFixed(0)} / ${DURATION} seconds (${((Date.now()-started)/1000).toFixed(1)} s elapsed)`);
  }
  ff.stdin.end();await done;
  console.log(`Wrote ${output}: ${width}x${height}, ${fps} fps, ${frames} frames.`);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
