/* Global Connect — original artwork, independently choreographed motion.
 * All coordinates in the component definitions refer to the supplied JPEG.
 * Nothing is retyped or redrawn in the finished logo. */
'use strict';
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const path = require('node:path');
const BLUE = '#1562ac';
const GREEN = '#9cc63b';
const DURATION = 9;
const BOUNDS = { x: 566, y: 848, w: 2446, h: 862 };
const clamp = v => Math.max(0, Math.min(1, v));
const progress = (t, start, duration) => clamp((t - start) / duration);
const smooth = p => p * p * (3 - 2 * p);
const smoother = p => p * p * p * (p * (p * 6 - 15) + 10);
const out = p => 1 - Math.pow(1 - p, 4);
const mix = (a, b, p) => a + (b - a) * p;
const cubic = (p, a, b, c, d) => {
  const q = 1 - p;
  return { x: q*q*q*a[0]+3*q*q*p*b[0]+3*q*p*p*c[0]+p*p*p*d[0],
    y: q*q*q*a[1]+3*q*q*p*b[1]+3*q*p*p*c[1]+p*p*p*d[1] };
};

async function createScene() {
  const original = await loadImage(path.join(__dirname, 'original-logo.jpeg'));
  const globeBox = [1221, 856, 361, 364];
  const letters = [
    { id:'G', box:[570,851,341,359], start:1.92, dur:0.91, dx:-137, dy:37, angle:-0.065 },
    { id:'L1', box:[960,857,261,348], start:2.06, dur:0.83, dx:-91, dy:24, angle:-0.035 },
    { id:'B', box:[1628,856,311,349], start:2.12, dur:0.86, dx:86, dy:-27, angle:0.045 },
    { id:'A', box:[1939,856,364,349], start:2.26, dur:0.85, dx:116, dy:-39, angle:0.055 },
    { id:'L2', box:[2323,856,267,349], start:2.40, dur:0.83, dx:141, dy:-49, angle:0.07 },
    ...[
      [1313,1231,206,349], [1544,1231,208,349], [1782,1239,194,334],
      [2011,1239,195,334], [2241,1239,171,334], [2436,1231,205,349], [2654,1239,193,334]
    ].map((box,i)=>({ id:'connect'+i, box, start:2.85+i*0.115, dur:0.90,
      dx:(i-3)*7, dy:82+i*3, angle:(i-3)*0.008, connect:true }))
  ];
  function makeCrop(box) {
    const c = createCanvas(box[2], box[3]);
    c.getContext('2d').drawImage(original, ...box, 0, 0, box[2], box[3]);
    return c;
  }
  for (const l of letters) l.image = makeCrop(l.box);
  // The top swoosh crosses the rectangular bounds of the final L.
  // Keep only the L silhouette in this tile, using the original pixels.
  {
    const l = letters[4], c = l.image.getContext('2d');
    c.save(); c.globalCompositeOperation='destination-out';
    c.fillRect(112,0,155,254); c.restore();
  }
  const globe = makeCrop(globeBox);
  const taglineBox = [1349,1607,1421,98];
  const tagline = makeCrop(taglineBox);
  const tmBox = [2880,1235,128,74];
  const tm = makeCrop(tmBox);
  const swashes = [
    { box:[2545,884,409,334], start:2.16, duration:1.43, width:98,
      curves:[[[2558,938],[2748,891],[2896,886],[2928,938]],[[2928,938],[2987,1009],[2824,1124],[2660,1210]]] },
    { box:[949,1307,389,323], start:3.02, duration:1.30, width:108,
      curves:[[[1248,1316],[1110,1406],[966,1514],[985,1566]],[[985,1566],[1004,1637],[1172,1619],[1327,1581]]] }
  ];
  for (const sw of swashes) {
    sw.image = makeCrop(sw.box);
    sw.mask = createCanvas(sw.box[2], sw.box[3]);
  }
  {
    const c=swashes[1].image.getContext('2d');c.save();c.globalCompositeOperation='destination-out';
    c.fillRect(362,0,27,270);c.restore();
  }
  const canvas = createCanvas(1920,1080);

  function render(t, width=1920, height=1080) {
    if (canvas.width!==width || canvas.height!==height) { canvas.width=width; canvas.height=height; }
    const ctx = canvas.getContext('2d');
    ctx.resetTransform(); ctx.globalAlpha=1; ctx.globalCompositeOperation='source-over'; ctx.filter='none';
    ctx.fillStyle='#ffffff'; ctx.fillRect(0,0,width,height);
    // Work in a 1920 x 1080 composition, with a little more breathing room in square crops.
    const viewport = Math.min(width/1920,height/1080) * (width===height ? 1.10 : 1);
    ctx.save(); ctx.translate(width/2,height/2); ctx.scale(viewport,viewport); ctx.translate(-960,-540);
    const scale = 0.563;
    const lx=(1920-BOUNDS.w*scale)/2, ly=(1080-BOUNDS.h*scale)/2;
    const xy=(x,y)=>({x:lx+(x-BOUNDS.x)*scale,y:ly+(y-BOUNDS.y)*scale});
    const fullLogo = alpha => {
      ctx.save(); ctx.globalAlpha=alpha;
      ctx.drawImage(original,BOUNDS.x,BOUNDS.y,BOUNDS.w,BOUNDS.h,lx,ly,BOUNDS.w*scale,BOUNDS.h*scale);
      ctx.restore();
    };
    if (t>=5.82) { fullLogo(1); ctx.restore(); return canvas; }

    const move = smoother(progress(t,1.57,1.17));
    const target=xy(1401.5,1038);
    const gx=mix(960,target.x,move), gy=mix(512,target.y,move);
    const gr=mix(145,180.5*scale,move);
    const openingAlpha = smooth(progress(t,0.07,0.4))*(1-smooth(progress(t,1.36,0.82)));

    // Two fine orbital paths build an airy, globe-shaped opening.
    function orbit(p, alpha, rotation, radiusX, radiusY, color, tail) {
      if (p<=0 || alpha<=0) return;
      ctx.save(); ctx.translate(gx,gy); ctx.rotate(rotation);
      ctx.strokeStyle=color; ctx.lineCap='round';
      const begin=-Math.PI*0.62, span=Math.PI*2*p;
      ctx.globalAlpha=alpha*0.38; ctx.lineWidth=1.4;
      ctx.beginPath(); ctx.ellipse(0,0,radiusX,radiusY,0,begin,begin+span); ctx.stroke();
      for(let i=0;i<26;i++) {
        const u=i/26, a=begin+span-(1-u)*0.52;
        if(a<begin)continue;
        ctx.globalAlpha=alpha*(0.025+u*0.7); ctx.lineWidth=1.2+u*0.75;
        ctx.beginPath(); ctx.ellipse(0,0,radiusX,radiusY,0,a,a+0.026); ctx.stroke();
      }
      if(tail) {
        const a=begin+span;
        ctx.globalAlpha=alpha; ctx.fillStyle=color;
        ctx.beginPath();ctx.arc(Math.cos(a)*radiusX,Math.sin(a)*radiusY,2.9,0,2*Math.PI);ctx.fill();
      }
      ctx.restore();
    }
    orbit(out(progress(t,0.10,1.4)),openingAlpha,-0.28,gr*1.75,gr*0.62,BLUE,true);
    orbit(smooth(progress(t,0.28,1.35)),openingAlpha*0.78,0.96,gr*1.35,gr*0.60,GREEN,true);

    // Longitude and latitude lines describe the sphere before the original globe resolves.
    if(t<1.8) {
      const wireAlpha=smooth(progress(t,0.16,0.5))*(1-smooth(progress(t,0.85,0.68)));
      const reveal=out(progress(t,0.14,1.06));
      ctx.save();ctx.translate(gx,gy);ctx.rotate(-0.22);ctx.strokeStyle=BLUE;ctx.lineWidth=1.6;
      ctx.globalAlpha=wireAlpha*0.76;
      for(const rx of [1,0.64,0.28]) {
        ctx.beginPath();ctx.ellipse(0,0,gr*rx,gr,0,-Math.PI/2,-Math.PI/2+Math.PI*2*reveal);ctx.stroke();
      }
      for(const y of [-0.48,0,0.48]) {
        ctx.beginPath();ctx.ellipse(0,gr*y,gr*Math.sqrt(1-y*y),gr*0.23,0,0,Math.PI*2*reveal);ctx.stroke();
      }
      ctx.restore();
    }

    // The native globe is revealed in a clockwise sweep, and travels into the O position.
    const globeReveal=smooth(progress(t,0.51,0.94));
    if(globeReveal>0) {
      ctx.save();ctx.translate(gx,gy);ctx.rotate(mix(-0.26,0,out(progress(t,0.51,1.25))));
      ctx.globalAlpha=smooth(progress(t,0.48,0.68));
      const radius=gr*1.025;
      if(globeReveal<0.9999){ctx.beginPath();ctx.moveTo(0,0);ctx.arc(0,0,radius,-Math.PI/2,-Math.PI/2+2*Math.PI*globeReveal);ctx.closePath();ctx.clip();}
      ctx.drawImage(globe,-gr,-gr*364/361,gr*2,gr*2*364/361);
      ctx.restore();
    }

    // Travel paths settle into the company's own swooshes.
    for(const sw of swashes) {
      const p=smoother(progress(t,sw.start,sw.duration));
      if(p<=0)continue;
      const mc=sw.mask.getContext('2d');mc.resetTransform();mc.clearRect(0,0,sw.box[2],sw.box[3]);
      mc.save();mc.translate(-sw.box[0],-sw.box[1]);mc.strokeStyle='#fff';mc.lineWidth=sw.width;mc.lineCap='round';mc.lineJoin='round';
      mc.beginPath();
      const n=160;
      for(let i=0;i<=Math.ceil(p*n);i++) {
        const q=Math.min(i/n,p), half=q<0.5?0:1, u=(q-half*0.5)*2;
        const point=cubic(u,...sw.curves[half]);
        if(i===0)mc.moveTo(point.x,point.y);else mc.lineTo(point.x,point.y);
      }
      mc.stroke();mc.restore();
      mc.globalCompositeOperation='source-in';mc.drawImage(sw.image,0,0);mc.globalCompositeOperation='source-over';
      const loc=xy(sw.box[0],sw.box[1]);
      ctx.save();ctx.globalCompositeOperation='multiply';ctx.drawImage(sw.mask,loc.x,loc.y,sw.box[2]*scale,sw.box[3]*scale);ctx.restore();
      // A tiny glint follows the draw-on and disappears at the pointed tip.
      if(p<0.97 && p>0.015) {
        const half=p<0.5?0:1, q=cubic((p-half*0.5)*2,...sw.curves[half]);
        const pt=xy(q.x,q.y);ctx.save();ctx.globalAlpha=Math.sin(p*Math.PI)*0.5;
        ctx.fillStyle=BLUE;ctx.beginPath();ctx.arc(pt.x,pt.y,2.1,0,2*Math.PI);ctx.fill();ctx.restore();
      }
    }

    for(const l of letters) {
      const p=progress(t,l.start,l.dur);if(p<=0)continue;
      const e=out(p), pos=xy(l.box[0]+l.box[2]/2,l.box[1]+l.box[3]/2);
      const extra=l.connect ? -2.0*Math.sin(p*Math.PI)*(p>0.6?1:0) : 0;
      ctx.save();ctx.translate(pos.x+l.dx*(1-e),pos.y+l.dy*(1-e)+extra);
      ctx.rotate(l.angle*(1-e));ctx.globalAlpha=smooth(progress(p,0,0.60));
      ctx.filter=p<0.65?`blur(${(1-e)*5.5}px)`:'none';ctx.globalCompositeOperation='multiply';
      const s=1+(l.connect?0.025:0.055)*(1-e);ctx.scale(s,s);
      ctx.drawImage(l.image,-l.box[2]*scale/2,-l.box[3]*scale/2,l.box[2]*scale,l.box[3]*scale);
      ctx.restore();
    }

    const tagP=progress(t,4.11,0.84);
    if(tagP>0) {
      const e=out(tagP), loc=xy(taglineBox[0],taglineBox[1]);
      ctx.save();ctx.globalAlpha=smooth(tagP);ctx.globalCompositeOperation='multiply';
      ctx.beginPath();ctx.rect(loc.x-2,loc.y-8,taglineBox[2]*scale*out(tagP)+4,taglineBox[3]*scale+30);ctx.clip();
      ctx.drawImage(tagline,loc.x,loc.y+12*(1-e),taglineBox[2]*scale,taglineBox[3]*scale);ctx.restore();
    }
    const tmP=smooth(progress(t,4.46,0.42));
    if(tmP>0){const loc=xy(tmBox[0],tmBox[1]);ctx.save();ctx.globalAlpha=tmP;ctx.globalCompositeOperation='multiply';ctx.drawImage(tm,loc.x,loc.y,tmBox[2]*scale,tmBox[3]*scale);ctx.restore();}

    // Resolve to the supplied full artwork to guarantee the exact finished arrangement.
    const resolve=smooth(progress(t,4.91,0.24));
    if(resolve>0)fullLogo(resolve);

    // Restrained finishing light: a broad 5% white highlight, then an unaltered logo hold.
    const sheen=progress(t,5.04,0.72);
    if(sheen>0 && sheen<1) {
      const x=lx-220+(BOUNDS.w*scale+440)*sheen;
      ctx.save();ctx.globalAlpha=0.10*Math.sin(Math.PI*sheen);
      const g=ctx.createLinearGradient(x-130,0,x+130,0);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(0.5,'rgba(255,255,255,1)');g.addColorStop(1,'rgba(255,255,255,0)');
      ctx.fillStyle=g;ctx.fillRect(lx,ly,BOUNDS.w*scale,BOUNDS.h*scale);ctx.restore();
    }
    ctx.restore();return canvas;
  }
  return { render, original, duration:DURATION };
}
module.exports={createScene,DURATION};
