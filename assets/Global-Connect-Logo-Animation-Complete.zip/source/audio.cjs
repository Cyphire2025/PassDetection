'use strict';
const fs=require('node:fs');
const path=require('node:path');
// Original synthesized sound design. No stock recording or external music.
const rate=48000,seconds=9,n=rate*seconds;
const left=new Float64Array(n),right=new Float64Array(n);
let seed=261906;
const noise=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296*2-1;};
function add(t,duration,fn,panFn=()=>0){
  const start=Math.floor(t*rate),len=Math.floor(duration*rate);
  for(let k=0;k<len&&start+k<n;k++){
    const u=k/rate,p=k/len,v=fn(u,p),pan=panFn(p);
    left[start+k]+=v*Math.sqrt((1-pan)*0.5);right[start+k]+=v*Math.sqrt((1+pan)*0.5);
  }
}
function bell(t,f,amp,d=2.5,pan=0){
  add(t,d,(u,p)=>{
    const attack=1-Math.exp(-u*90),tail=Math.pow(1-p,1.8);
    return amp*attack*tail*(Math.sin(2*Math.PI*f*u)*Math.exp(-u*1.35)
      +0.22*Math.sin(2*Math.PI*f*2.003*u)*Math.exp(-u*3.8)
      +0.06*Math.sin(2*Math.PI*f*3.997*u)*Math.exp(-u*7));
  },()=>pan);
}
function air(t,duration,amp,from=-0.5,to=0.5){
  let low=0;
  add(t,duration,(u,p)=>{const v=noise();low=low*0.88+v*0.12;
    const envelope=Math.pow(Math.sin(Math.PI*p),2.4);
    return (low*0.82+v*0.07)*amp*envelope;
  },p=>from+(to-from)*p);
}
// A quiet warm foundation, two travel sweeps, and a resolving D-major signature.
add(0.15,5.5,(u,p)=>{
  const env=Math.pow(Math.sin(Math.PI*p),2)*0.020;
  return env*(Math.sin(2*Math.PI*146.832*u)+0.45*Math.sin(2*Math.PI*220*u)+0.26*Math.sin(2*Math.PI*293.665*u));
});
air(0.10,1.30,0.20,-0.7,0.5);
bell(0.48,587.33,0.090,2.1,-0.2);
bell(1.05,880.00,0.055,2.0,0.2);
air(1.55,1.13,0.18,0.5,-0.35);
air(2.16,1.42,0.17,-0.65,0.65);
air(3.01,1.32,0.14,0.65,-0.45);
for(let i=0;i<7;i++)bell(2.94+i*0.115,1174.66+19*i,0.006,0.18,(i-3)*0.12);
bell(4.21,587.33,0.12,3.4,-0.22);
bell(4.38,739.99,0.087,3.2,0.12);
bell(4.56,880.00,0.072,3.0,0.24);
bell(4.74,1174.66,0.033,2.5,-0.05);
air(5.04,0.76,0.055,-0.4,0.4);
// Short stereo echoes provide space without obscuring the logo's clean finish.
const dryL=left.slice(),dryR=right.slice();
for(const [delay,gain] of [[0.071,0.16],[0.127,0.11],[0.213,0.07]]){
  const offset=Math.floor(delay*rate);
  for(let i=offset;i<n;i++){left[i]+=dryR[i-offset]*gain;right[i]+=dryL[i-offset]*gain;}
}
let peak=0;for(let i=0;i<n;i++)peak=Math.max(peak,Math.abs(left[i]),Math.abs(right[i]));
const level=0.59/peak;
const bytes=Buffer.alloc(44+n*4);bytes.write('RIFF');bytes.writeUInt32LE(bytes.length-8,4);bytes.write('WAVEfmt ',8);
bytes.writeUInt32LE(16,16);bytes.writeUInt16LE(1,20);bytes.writeUInt16LE(2,22);bytes.writeUInt32LE(rate,24);
bytes.writeUInt32LE(rate*4,28);bytes.writeUInt16LE(4,32);bytes.writeUInt16LE(16,34);bytes.write('data',36);bytes.writeUInt32LE(n*4,40);
for(let i=0;i<n;i++){
  const fade=Math.min(1,i/(rate*0.03),(n-1-i)/(rate*0.30));
  bytes.writeInt16LE(Math.round(Math.max(-1,Math.min(1,left[i]*level*fade))*32767),44+i*4);
  bytes.writeInt16LE(Math.round(Math.max(-1,Math.min(1,right[i]*level*fade))*32767),46+i*4);
}
const target=path.join(__dirname,'sonic-logo.wav');fs.writeFileSync(target,bytes);
console.log(`Original sound design: ${seconds}s, ${rate} Hz stereo; ${target}`);
